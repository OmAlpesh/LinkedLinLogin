//
//  HeaderBridge.h
//  LoginWithLinkedIn
//
//  Created by piyush sinroja on 20/12/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

#ifndef HeaderBridge_h
#define HeaderBridge_h

#import <LinkedinSwift/LSHeader.h>

#endif /* HeaderBridge_h */
